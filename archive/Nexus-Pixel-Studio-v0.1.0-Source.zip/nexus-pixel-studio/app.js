/* Nexus Pixel Studio v0.1 — self-contained HTML Canvas pixel editor.
   RGBA document model: a separate transparent canvas for every layer/frame cel.
   Data stays on the user's device; no accounts or remote services required. */
'use strict';
const $ = id => document.getElementById(id);
const PALETTES = {
 DB32:['000000','222034','45283C','663931','8F563B','DF7126','D9A066','EEC39A','FBF236','99E550','6ABE30','37946E','4B692F','524B24','323C39','3F3F74','306082','5B6EE1','639BFF','5FCDE4','CBDBFC','FFFFFF','9BADB7','847E87','696A6A','595652','76428A','AC3232','D95763','D77BBA','8F974A','8A6F30'],
 PICO8:['000000','1D2B53','7E2553','008751','AB5236','5F574F','C2C3C7','FFF1E8','FF004D','FFA300','FFEC27','00E436','29ADFF','83769C','FF77A8','FFCCAA'],
 FANTASY:['101626','1A2846','263861','354D74','52749D','7A9FB0','CCE7C3','F8F5C9','182D29','245C4D','3E8665','78B879','B7DE88','E1F5B1','50416A','7A5B99','A18CC6','DBA2D4','653A41','A85B50','DE8965','F5BC7D','FFE1A1','FFFFFF']
};
const $canvas=()=>document.createElement('canvas');
function makeCanvas(w,h){const c=$canvas();c.width=w;c.height=h;return c}
function ctx(c){return c.getContext('2d',{willReadFrequently:true})}
function id(){return Math.random().toString(36).slice(2,9)}
function clamp(x,a,b){return Math.min(b,Math.max(a,x))}
function hexToRGB(h){const v=h.replace('#','');return [parseInt(v.slice(0,2),16),parseInt(v.slice(2,4),16),parseInt(v.slice(4,6),16)]}
function rgbToHex(r,g,b){return '#'+[r,g,b].map(x=>Math.round(x).toString(16).padStart(2,'0')).join('')}
function normalHex(h){return /^#?[a-fA-F0-9]{6}$/.test(h)?'#'+h.replace('#','').toUpperCase():null}
function safeName(s){return (s||'sprite').replace(/[^a-z0-9_-]+/ig,'-').slice(0,65)}
function layer(name,w,h,count){return {id:id(),name,visible:true,locked:false,opacity:1,cels:Array.from({length:count},()=>makeCanvas(w,h))}}
function blankProject(w,h,name,white=false){const result={format:'NexusPixelStudio',version:1,name,width:w,height:h,frames:[{duration:125}],layers:[layer(white?'Background':'Layer 1',w,h,1)],paletteKey:'DB32',palette:PALETTES.DB32.map(x=>'#'+x)};if(white){const c=ctx(result.layers[0].cels[0]);c.fillStyle='#ffffff';c.fillRect(0,0,w,h)}return result}
function seedProject(){
 const w=48,h=48,n=4;const result={format:'NexusPixelStudio',version:1,name:'Slime Study',width:w,height:h,frames:Array.from({length:n},()=>({duration:150})),layers:[layer('Ground',w,h,n),layer('Slime',w,h,n),layer('Highlights',w,h,n)],paletteKey:'FANTASY',palette:PALETTES.FANTASY.map(x=>'#'+x)};
 function block(c,col,x,y,wd=1,ht=1){c.fillStyle=col;c.fillRect(Math.round(x),Math.round(y),wd,ht)}
 for(let f=0;f<n;f++){
  const g=ctx(result.layers[0].cels[f]);const y= f===3?1:(f===1?-1:0);
  for(let x=5;x<=43;x++){
   const dy=Math.pow((x-24)/20,2);
   for(let py=36;py<=40-dy*4;py++)block(g,py<=37?'#245C4D':(py===38?'#3E8665':'#354D74'),x,py);
   if(x%7===1)block(g,'#78B879',x,35+(x%3));
  }
  for(let x=13;x<=35;x++)block(g,'#182D29',x,37,1,2);
  const s=ctx(result.layers[1].cels[f]);
  // Pixel-defined slime body, fully editable on each cel.
  for(let py=14;py<=35;py++){
   let half=py<17?5+py-14:py<23?10+Math.floor((py-17)/2):py<33?13:13-(py-33)*2;
   if(py>=33)half=13-(py-33);
   const left=24-half, right=24+half;
   for(let x=left;x<=right;x++){
    let color='#245C4D';
    if(x>left+1&&x<right-1&&py>15)color=py<23?'#78B879':(x<20?'#3E8665':'#78B879');
    if(x>23&&py<30&&x<right-2)color='#B7DE88';
    if(py>=32&&x>left+3&&x<right-2)color='#3E8665';
    block(s,color,x,py+y);
   }
  }
  block(s,'#E1F5B1',17,18+y,5,2);block(s,'#E1F5B1',16,20+y,3,4);
  block(s,'#182D29',18,25+y,4,5);block(s,'#182D29',27,25+y,4,5);
  if(f!==2){block(s,'#F8F5C9',18,25+y,3,3);block(s,'#F8F5C9',27,25+y,3,3);block(s,'#263861',20,26+y,1,2);block(s,'#263861',28,26+y,1,2)}
  else{block(s,'#182D29',18,27+y,3,1);block(s,'#182D29',27,27+y,3,1)}
  block(s,'#245C4D',23,31+y,4,1);block(s,'#182D29',24,32+y,2,1);
  block(s,'#DE8965',16,29+y,2,2);block(s,'#DE8965',31,29+y,2,2);
  const hctx=ctx(result.layers[2].cels[f]);
  const sparkles=[[9,14],[39,12],[7,29],[40,27],[35,5]];
  for(let i=0;i<sparkles.length;i++){
   const [x,sy]=sparkles[i];if((i+f)%3===0)continue;
   block(hctx,i%2?'#CCE7C3':'#F8F5C9',x+(f%2),sy);block(hctx,'#7A9FB0',x+(f%2)-1,sy+1);if((i+f)%2===0){block(hctx,'#CCE7C3',x+(f%2),sy-2);block(hctx,'#CCE7C3',x+(f%2),sy+2)}
  }
 }
 return result;
}
let project, history=[], future=[];
let state={tool:'pencil',frame:0,layer:1,fg:'#A6E35F',bg:'#263861',brush:1,zoom:8,panX:0,panY:0,grid:false,onion:false,symX:false,symY:false,filled:false,playing:false,selection:null,clipboard:null,drag:null,space:false,dirty:false};
const maxHistory=24, historyMemoryLimit=80*1024*1024;
const documentMemoryLimit=96*1024*1024;
function fitsMemoryBudget(width=project.width,height=project.height,frames=project.frames.length,layers=project.layers.length){return width*height*4*frames*layers<=documentMemoryLimit}
let autosaveTimer=null,toastTimer=null,renderCount=0,animationTime=0,animationLast=0;
function selectedLayer(){return project.layers[state.layer]}
function selectedCel(){return selectedLayer().cels[state.frame]}
function copyCel(c){const copy=makeCanvas(c.width,c.height);ctx(copy).drawImage(c,0,0);return copy}
function capture(){return {name:project.name,width:project.width,height:project.height,frames:project.frames.map(f=>({...f})),layers:project.layers.map(l=>({id:l.id,name:l.name,visible:l.visible,locked:l.locked,opacity:l.opacity,pixels:l.cels.map(c=>ctx(c).getImageData(0,0,c.width,c.height))})),palette:[...project.palette],paletteKey:project.paletteKey,frame:state.frame,layer:state.layer}}
function restore(s){project={format:'NexusPixelStudio',version:1,name:s.name,width:s.width,height:s.height,frames:s.frames.map(x=>({...x})),palette:[...s.palette],paletteKey:s.paletteKey,layers:s.layers.map(l=>({id:l.id,name:l.name,visible:l.visible,locked:l.locked,opacity:l.opacity,cels:l.pixels.map(p=>{const c=makeCanvas(s.width,s.height);ctx(c).putImageData(p,0,0);return c})}))};state.frame=clamp(s.frame,0,project.frames.length-1);state.layer=clamp(s.layer,0,project.layers.length-1);state.selection=null;state.playing=false;refreshAll();changed()}
function memoryOf(s){return s.width*s.height*4*s.frames.length*s.layers.length}
function checkpoint(){history.push(capture());future=[];while(history.length>maxHistory)history.shift();let size=history.reduce((n,s)=>n+memoryOf(s),0);while(history.length>1&&size>historyMemoryLimit){size-=memoryOf(history.shift())}updateUndoButtons()}
function undo(){if(!history.length)return;future.push(capture());restore(history.pop());updateUndoButtons();toast('Undo applied')}
function redo(){if(!future.length)return;history.push(capture());restore(future.pop());updateUndoButtons();toast('Redo applied')}
function updateUndoButtons(){$('undoBtn').disabled=!history.length;$('redoBtn').disabled=!future.length}
function changed(){state.dirty=true;$('dirtyDot').classList.add('dirty');$('saveStatus').textContent='Saving…';clearTimeout(autosaveTimer);autosaveTimer=setTimeout(autosave,800)}
function autosave(){try{localStorage.setItem('nexus-pixel-studio-autosave-v1',JSON.stringify(serialize()));state.dirty=false;$('dirtyDot').classList.remove('dirty');$('saveStatus').textContent='Saved locally'}catch(e){$('saveStatus').textContent='Autosave unavailable';console.warn('Autosave skipped:',e)}}
function serialize(){return {...Object.fromEntries(['format','version','name','width','height','frames','paletteKey','palette'].map(k=>[k,project[k]])),layers:project.layers.map(l=>({id:l.id,name:l.name,visible:l.visible,locked:l.locked,opacity:l.opacity,cels:l.cels.map(c=>c.toDataURL('image/png'))}))}}
async function loadSerialized(data){
 if(data?.format!=='NexusPixelStudio'||!Number.isInteger(data.width)||!Number.isInteger(data.height)||data.width<1||data.height<1||data.width>512||data.height>512||!Array.isArray(data.frames)||!data.frames.length||data.frames.length>128||!Array.isArray(data.layers)||!data.layers.length||data.layers.length>64)throw Error('Invalid or unsupported Nexus Pixel project');
 if(data.frames.length*data.layers.length*data.width*data.height*4>documentMemoryLimit)throw Error('Project exceeds safe editor memory budget');
 const loaded={format:'NexusPixelStudio',version:1,name:String(data.name||'Imported').slice(0,60),width:data.width,height:data.height,frames:data.frames.map(f=>({duration:clamp(Number(f.duration)||125,20,5000)})),paletteKey:data.paletteKey||'CUSTOM',palette:Array.isArray(data.palette)?data.palette.map(normalHex).filter(Boolean).slice(0,256):[...PALETTES.DB32],layers:[]};
 for(const l of data.layers){if(!Array.isArray(l.cels)||l.cels.length!==loaded.frames.length)throw Error('Missing cels in layer');const next=layer(String(l.name||'Layer'),loaded.width,loaded.height,loaded.frames.length);next.id=String(l.id||id());next.visible=l.visible!==false;next.locked=!!l.locked;next.opacity=clamp(Number(l.opacity??1),0,1);
  for(let f=0;f<l.cels.length;f++){if(typeof l.cels[f]!=='string'||!l.cels[f].startsWith('data:image/png;base64,'))throw Error('Invalid cel image');const im=new Image();im.src=l.cels[f];await im.decode();if(im.width!==loaded.width||im.height!==loaded.height)throw Error('Cel dimensions mismatch');ctx(next.cels[f]).drawImage(im,0,0)}loaded.layers.push(next)}
 project=loaded;state.frame=0;state.layer=loaded.layers.length-1;state.selection=null;state.playing=false;history=[];future=[];refreshAll();changed();toast('Project opened')
}
function composeFrame(index,onlyVisible=true){const out=makeCanvas(project.width,project.height),c=ctx(out);for(const l of project.layers){if(onlyVisible&&!l.visible)continue;c.globalAlpha=l.opacity;c.drawImage(l.cels[index],0,0)}c.globalAlpha=1;return out}
function celHasPixels(canvas){const data=ctx(canvas).getImageData(0,0,canvas.width,canvas.height).data;for(let i=3;i<data.length;i+=4)if(data[i])return true;return false}
function renderCanvas(){const w=project.width,h=project.height;const main=$('renderCanvas'),oc=$('onionCanvas');if(main.width!==w||main.height!==h){main.width=oc.width=$('interactiveCanvas').width=w;main.height=oc.height=$('interactiveCanvas').height=h}const m=ctx(main);m.clearRect(0,0,w,h);m.drawImage(composeFrame(state.frame),0,0);
 const o=ctx(oc);o.clearRect(0,0,w,h);if(state.onion&&project.frames.length>1){o.globalAlpha=.28;o.drawImage(composeFrame((state.frame-1+project.frames.length)%project.frames.length),0,0);o.globalAlpha=.13;o.drawImage(composeFrame((state.frame+1)%project.frames.length),0,0);o.globalAlpha=1}
 const p=$('previewCanvas');if(p.width!==w||p.height!==h){p.width=w;p.height=h}const pc=ctx(p);pc.clearRect(0,0,w,h);pc.drawImage(composeFrame(state.frame),0,0);$('previewFrame').textContent=`${String(state.frame+1).padStart(2,'0')} / ${String(project.frames.length).padStart(2,'0')}`;renderCount++}
function updateArtboard(){const w=project.width*state.zoom,h=project.height*state.zoom;const a=$('artboard');a.style.width=w+'px';a.style.height=h+'px';a.style.marginLeft=state.panX+'px';a.style.marginTop=state.panY+'px';$('zoomValue').textContent=Math.round(state.zoom*100)+'%';const g=$('pixelGrid');g.classList.toggle('on',state.grid&&state.zoom>=7);g.style.backgroundImage='linear-gradient(90deg,#0b162a41 1px, transparent 1px),linear-gradient(#0b162a41 1px, transparent 1px)';g.style.backgroundSize=`${state.zoom}px ${state.zoom}px`;g.style.backgroundPosition='0 0';updateSelectionBox()}
function updateSelectionBox(){const s=state.selection,box=$('selectionBox');if(!s||s.w<1||s.h<1){box.hidden=true;return}box.hidden=false;box.style.left=s.x*state.zoom+'px';box.style.top=s.y*state.zoom+'px';box.style.width=s.w*state.zoom+'px';box.style.height=s.h*state.zoom+'px'}
function setZoom(value,around=null){state.zoom=clamp(Math.round(value),2,32);updateArtboard()}
function fit(){const v=$('viewport');state.panX=0;state.panY=0;setZoom(Math.floor(Math.min((v.clientWidth-140)/project.width,(v.clientHeight-100)/project.height,16))||2)}
function updateTimeline(){
 const n=project.frames.length,grid=$('timelineGrid');grid.replaceChildren();grid.style.gridTemplateColumns=`186px repeat(${n}, 58px)`;
 const head=document.createElement('div');head.className='timeline-header';head.textContent='LAYERS / FRAMES';grid.append(head);
 for(let f=0;f<n;f++){const b=document.createElement('button');b.className='frame-header'+(f===state.frame?' active':'');b.innerHTML=`${String(f+1).padStart(2,'0')}`;b.title=`Frame ${f+1} · ${project.frames[f].duration} ms`;b.onclick=()=>{state.frame=f;renderCanvas();updateTimeline();updateMetadata()};grid.append(b)}
 for(let i=project.layers.length-1;i>=0;i--){const l=project.layers[i];const lab=document.createElement('div');lab.className='timeline-layer'+(i===state.layer?' active':'');
 const eye=document.createElement('button');eye.className='layer-visibility'+(l.visible?'':' off');eye.textContent=l.visible?'◉':'◌';eye.title='Toggle visibility';eye.onclick=()=>{checkpoint();l.visible=!l.visible;refreshAll();changed()};
 const lock=document.createElement('button');lock.className='layer-lock'+(l.locked?' locked':'');lock.textContent=l.locked?'▣':'♙';lock.title='Toggle lock';lock.onclick=()=>{checkpoint();l.locked=!l.locked;refreshAll();changed()};
 const nam=document.createElement('button');nam.className='layer-label';nam.textContent=l.name;nam.title='Select; double-click to rename';nam.onclick=()=>{state.layer=i;refreshAll()};nam.ondblclick=()=>{const value=prompt('Layer name',l.name);if(value?.trim()){checkpoint();l.name=value.trim().slice(0,40);refreshAll();changed()}};
 lab.append(eye,lock,nam);grid.append(lab);
 for(let f=0;f<n;f++){const c=l.cels[f],cell=document.createElement('button');cell.className='cel'+(state.layer===i&&state.frame===f?' active':'')+(state.frame===f?' current-frame':'');cell.title=`${l.name} / Frame ${f+1}`;if(celHasPixels(c)){const img=new Image();img.src=c.toDataURL();cell.append(img)}else{const empty=document.createElement('i');empty.className='cel-empty';cell.append(empty)}cell.onclick=()=>{state.frame=f;state.layer=i;refreshAll()};grid.append(cell)}
 }
 $('frameCountLabel').textContent=`${n} frame${n===1?'':'s'}`;
}
function updateInspector(){const l=selectedLayer();$('docName').value=project.name;$('docMeta').textContent=`${project.width} × ${project.height} px · RGBA`;$('sizeLabel').textContent=`${project.width} × ${project.height}`;$('previewName').textContent=project.name;$('layerName').value=l.name;$('layerOpacity').value=Math.round(l.opacity*100);$('opacityReadout').textContent=Math.round(l.opacity*100)+'%';$('toggleLayerVisibility').textContent=l.visible?'◉ Visible':'◌ Hidden';$('toggleLayerLock').textContent=l.locked?'▣ Locked':'♙ Unlocked';$('layerIndex').textContent=`${String(state.layer+1).padStart(2,'0')} / ${String(project.layers.length).padStart(2,'0')}`;
 $('activeCellLabel').textContent=`${l.name} · Frame ${state.frame+1}`;$('fpsInput').value=clamp(Math.round(1000/project.frames[state.frame].duration),1,30);$('canvasToolName').textContent=state.tool.replace(/^[a-z]/,c=>c.toUpperCase());$('statusTool').textContent=state.tool.toUpperCase();
 $('brushSize').value=state.brush;$('brushSizeLabel').textContent=state.brush+' px';$('gridToggle').classList.toggle('selected',state.grid);$('onionToggle').classList.toggle('selected',state.onion);$('symXToggle').classList.toggle('selected',state.symX);$('symYToggle').classList.toggle('selected',state.symY);$('filledToggle').classList.toggle('selected',state.filled);
 $('fgSwatch').style.background=state.fg;$('bgSwatch').style.background=state.bg;$('colorHex').value=state.fg.slice(1);$('colorPicker').value=state.fg.toLowerCase();
 $('paletteSelect').value=project.paletteKey in PALETTES||project.paletteKey==='CUSTOM'?project.paletteKey:'CUSTOM';
 $('paletteGrid').replaceChildren();project.palette.forEach((color,i)=>{const sw=document.createElement('button');sw.className='palette-swatch'+(state.fg.toLowerCase()===color.toLowerCase()?' active':'');sw.style.background=color;sw.title=`${i+1}: ${color}`;sw.onclick=e=>{if(e.button===2)return;setForeground(color)};sw.oncontextmenu=e=>{e.preventDefault();state.bg=color;updateInspector()};sw.ondblclick=()=>{const value=prompt('Edit palette color (HEX)',color);const updated=normalHex(value||'');if(updated){checkpoint();project.paletteKey='CUSTOM';project.palette[i]=updated;updateInspector();changed()}};$('paletteGrid').append(sw)});$('paletteInfo').textContent=project.palette.length+' swatches';
 document.querySelectorAll('[data-tool]').forEach(b=>b.classList.toggle('active',b.dataset.tool===state.tool));$('playBtn').textContent=state.playing?'❚❚':'▶';$('previewToggle').textContent=state.playing?'❚❚':'▶';updateUndoButtons()}
function updateMetadata(){$('activeCellLabel').textContent=selectedLayer().name+' · Frame '+(state.frame+1);$('fpsInput').value=clamp(Math.round(1000/project.frames[state.frame].duration),1,30)}
function refreshAll(){renderCanvas();updateArtboard();updateInspector();updateTimeline()}
function toast(message){const t=$('toast');t.textContent=message;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),2500)}
function setForeground(col){const c=normalHex(col);if(!c)return;state.fg=c;updateInspector()}
function swapColors(){[state.fg,state.bg]=[state.bg,state.fg];updateInspector()}
function setTool(tool){state.tool=tool;state.drag=null;updateInspector()}
// ----- Pixel operations: integer coordinates; no anti-aliasing -----
function canvasPoint(e){const r=$('artboard').getBoundingClientRect();return {x:Math.floor((e.clientX-r.left)/state.zoom),y:Math.floor((e.clientY-r.top)/state.zoom)}}
function inside(x,y){return x>=0&&y>=0&&x<project.width&&y<project.height}
function withinSelection(x,y){const s=state.selection;return !s||(x>=s.x&&y>=s.y&&x<s.x+s.w&&y<s.y+s.h)}
function paintPixel(c,x,y,color,eraser=false,dither=false){const w=project.width,h=project.height,size=state.brush,off=Math.floor((size-1)/2);const positions=[[x,y]];if(state.symX)positions.push([w-1-x,y]);if(state.symY){positions.push([x,h-1-y]);if(state.symX)positions.push([w-1-x,h-1-y])}
 for(const [cx,cy]of positions){for(let py=cy-off;py<cy-off+size;py++)for(let px=cx-off;px<cx-off+size;px++){if(!inside(px,py)||!withinSelection(px,py))continue;if(dither&&(px+py)%2!==0)continue;if(eraser)c.clearRect(px,py,1,1);else{c.fillStyle=color;c.fillRect(px,py,1,1)}}}
}
function bresenham(x0,y0,x1,y1,fn){let dx=Math.abs(x1-x0),dy=-Math.abs(y1-y0),sx=x0<x1?1:-1,sy=y0<y1?1:-1,err=dx+dy;while(true){fn(x0,y0);if(x0===x1&&y0===y1)break;const e=2*err;if(e>=dy){err+=dy;x0+=sx}if(e<=dx){err+=dx;y0+=sy}}}
function strokeSegment(c,a,b,color,eraser=false,dither=false){bresenham(a.x,a.y,b.x,b.y,(x,y)=>paintPixel(c,x,y,color,eraser,dither))}
function drawShape(c,tool,a,b,color){
 const x0=Math.min(a.x,b.x),y0=Math.min(a.y,b.y),x1=Math.max(a.x,b.x),y1=Math.max(a.y,b.y);
 const d=(x,y)=>paintPixel(c,x,y,color,false,false);
 if(tool==='line'){bresenham(a.x,a.y,b.x,b.y,d);return}
 if(tool==='rect'){if(state.filled){for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)d(x,y)}else{bresenham(x0,y0,x1,y0,d);bresenham(x0,y1,x1,y1,d);bresenham(x0,y0,x0,y1,d);bresenham(x1,y0,x1,y1,d)}return}
 if(tool==='ellipse'){
  const rx=(x1-x0)/2,ry=(y1-y0)/2,cx=(x0+x1)/2,cy=(y0+y1)/2;
  if(rx===0||ry===0){bresenham(x0,y0,x1,y1,d);return}
  if(state.filled){for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){if(Math.pow((x-cx)/rx,2)+Math.pow((y-cy)/ry,2)<=1.05)d(x,y)}}
  else{const steps=Math.ceil(2*Math.PI*Math.max(rx,ry)*3);for(let i=0;i<=steps;i++){const t=i/steps*2*Math.PI;d(Math.round(cx+rx*Math.cos(t)),Math.round(cy+ry*Math.sin(t)))}}
 }
}
function floodFill(c,x,y,color){if(!inside(x,y)||!withinSelection(x,y))return;const w=project.width,h=project.height,cx=ctx(c),image=cx.getImageData(0,0,w,h),data=image.data;const start=(y*w+x)*4,target=Array.from(data.slice(start,start+4)),newCol=[...hexToRGB(color),255];if(target.every((v,i)=>v===newCol[i]))return;
 const visited=new Uint8Array(w*h),stack=[y*w+x];while(stack.length){const n=stack.pop();if(visited[n])continue;visited[n]=1;const xx=n%w,yy=Math.floor(n/w),offset=n*4;if(!withinSelection(xx,yy))continue;if(data[offset]!==target[0]||data[offset+1]!==target[1]||data[offset+2]!==target[2]||data[offset+3]!==target[3])continue;data.set(newCol,offset);
  if(xx>0)stack.push(n-1);if(xx<w-1)stack.push(n+1);if(yy>0)stack.push(n-w);if(yy<h-1)stack.push(n+w)
 }cx.putImageData(image,0,0)}
function pickColor(x,y){if(!inside(x,y))return;const d=ctx(composeFrame(state.frame)).getImageData(x,y,1,1).data;if(!d[3]){toast('Transparent pixel');return}setForeground(rgbToHex(d[0],d[1],d[2]))}
function normRect(a,b){const x=clamp(Math.min(a.x,b.x),0,project.width-1),y=clamp(Math.min(a.y,b.y),0,project.height-1),ex=clamp(Math.max(a.x,b.x),0,project.width-1),ey=clamp(Math.max(a.y,b.y),0,project.height-1);return {x,y,w:ex-x+1,h:ey-y+1}}
function finishDraw(){state.drag=null;renderCanvas();updateTimeline();updateSelectionBox();changed()}
function stopPlayback(){if(!state.playing)return;state.playing=false;updateInspector()}
function handlePointerDown(e){if(e.button!==0&&e.button!==1&&e.button!==2)return;e.preventDefault();const target=$('viewport');const point=canvasPoint(e);const pan=state.space||state.tool==='hand'||e.button===1;
 if(pan){state.drag={tool:'pan',originX:e.clientX,originY:e.clientY,panX:state.panX,panY:state.panY};target.setPointerCapture(e.pointerId);target.style.cursor='grabbing';return}
 if(!inside(point.x,point.y))return;
 target.setPointerCapture(e.pointerId);stopPlayback();
 if(state.tool==='eyedropper'){pickColor(point.x,point.y);return}
 if(state.tool==='select'){state.drag={tool:'select',start:point};state.selection=normRect(point,point);updateSelectionBox();return}
 const l=selectedLayer();if(l.locked){toast('Unlock layer to edit pixels');return}if(!l.visible){toast('Show layer to edit pixels');return}
 const tool=state.tool,cell=selectedCel(),c=ctx(cell),color=e.button===2?state.bg:state.fg;
 if(tool==='move'){
  if(!state.selection)state.selection={x:0,y:0,w:project.width,h:project.height};const s={...state.selection};const base=c.getImageData(0,0,project.width,project.height);const original=copyCel(cell);state.drag={tool, start:point,last:point,base,s,original,moved:false};updateSelectionBox();return;
 }
 checkpoint();const straight=e.shiftKey&&['pencil','eraser','dither'].includes(tool);state.drag={tool,start:point,last:point,straight,base:(straight||['line','rect','ellipse'].includes(tool))?c.getImageData(0,0,project.width,project.height):null,color,moved:false};
 if(tool==='fill'){floodFill(cell,point.x,point.y,color);finishDraw();return}
 if(['pencil','eraser','dither'].includes(tool)){paintPixel(c,point.x,point.y,color,tool==='eraser',tool==='dither');renderCanvas()}
}
function handlePointerMove(e){const point=canvasPoint(e);$('coordLabel').innerHTML=inside(point.x,point.y)?`x: ${point.x} &nbsp; y: ${point.y}`:'x: — &nbsp; y: —';const d=state.drag;if(!d)return;
 if(d.tool==='pan'){state.panX=d.panX+(e.clientX-d.originX);state.panY=d.panY+(e.clientY-d.originY);updateArtboard();return}
 if(d.tool==='select'){state.selection=normRect(d.start,point);updateSelectionBox();return}
 const l=selectedLayer(),c=ctx(l.cels[state.frame]);const p={x:clamp(point.x,0,project.width-1),y:clamp(point.y,0,project.height-1)};
 if(d.tool==='move'){
  const dx=p.x-d.start.x,dy=p.y-d.start.y;savedMove(c,d,dx,dy);d.moved=dx!==0||dy!==0;d.last=p;state.selection={x:clamp(d.s.x+dx,0,project.width-1),y:clamp(d.s.y+dy,0,project.height-1),w:d.s.w,h:d.s.h};updateSelectionBox();renderCanvas();return;
 }
 if(['pencil','eraser','dither'].includes(d.tool)){if(d.straight)c.putImageData(d.base,0,0);strokeSegment(c,d.straight?d.start:d.last,p,d.color,d.tool==='eraser',d.tool==='dither');d.last=p;d.moved=true;renderCanvas()}
 else if(['line','rect','ellipse'].includes(d.tool)){c.putImageData(d.base,0,0);drawShape(c,d.tool,d.start,p,d.color);d.last=p;d.moved=true;renderCanvas()}
}
function savedMove(c,d,dx,dy){c.putImageData(d.base,0,0);c.clearRect(d.s.x,d.s.y,d.s.w,d.s.h);c.drawImage(d.original,d.s.x,d.s.y,d.s.w,d.s.h,d.s.x+dx,d.s.y+dy,d.s.w,d.s.h)}
function handlePointerUp(e){const d=state.drag;if(!d)return;if(d.tool==='pan'){$('viewport').style.cursor='crosshair';state.drag=null;return}
 if(d.tool==='select'){state.drag=null;updateSelectionBox();return}
 if(d.tool==='move'){if(d.moved){const c=ctx(selectedCel());c.putImageData(d.base,0,0);checkpoint();savedMove(c,d,d.last.x-d.start.x,d.last.y-d.start.y);finishDraw()}else state.drag=null;return}
 if(['line','rect','ellipse'].includes(d.tool)&&!d.moved){const c=ctx(selectedCel());drawShape(c,d.tool,d.start,d.start,d.color)}finishDraw()}
function copySelection(cut=false){const s=state.selection||{x:0,y:0,w:project.width,h:project.height};state.clipboard=ctx(selectedCel()).getImageData(s.x,s.y,s.w,s.h);if(cut){checkpoint();ctx(selectedCel()).clearRect(s.x,s.y,s.w,s.h);finishDraw()}toast(cut?'Pixels cut':'Pixels copied')}
function pasteSelection(){if(!state.clipboard){toast('Nothing copied yet');return}if(selectedLayer().locked){toast('Unlock layer first');return}checkpoint();const clip=state.clipboard,temp=makeCanvas(clip.width,clip.height);ctx(temp).putImageData(clip,0,0);const x=state.selection?.x??Math.floor((project.width-clip.width)/2),y=state.selection?.y??Math.floor((project.height-clip.height)/2);ctx(selectedCel()).drawImage(temp,x,y);state.selection={x:clamp(x,0,project.width-1),y:clamp(y,0,project.height-1),w:Math.min(clip.width,project.width-x),h:Math.min(clip.height,project.height-y)};finishDraw();toast('Pixels pasted')}
function deleteSelection(){if(selectedLayer().locked)return toast('Unlock layer first');checkpoint();const s=state.selection||{x:0,y:0,w:project.width,h:project.height};ctx(selectedCel()).clearRect(s.x,s.y,s.w,s.h);finishDraw()}
function applyFlip(horizontal){if(selectedLayer().locked)return toast('Unlock layer first');checkpoint();const c=selectedCel(),original=copyCel(c),g=ctx(c);g.clearRect(0,0,c.width,c.height);g.save();if(horizontal){g.translate(c.width,0);g.scale(-1,1)}else{g.translate(0,c.height);g.scale(1,-1)}g.drawImage(original,0,0);g.restore();finishDraw()}
// ----- Layers, animation, document actions -----
function addFrame(duplicate=false){if(project.frames.length>=128){toast('Maximum 128 frames');return}if(!fitsMemoryBudget(project.width,project.height,project.frames.length+1,project.layers.length))return toast('Document memory limit reached');checkpoint();const current=state.frame;project.frames.splice(current+1,0,{duration:project.frames[current].duration});for(const l of project.layers){l.cels.splice(current+1,0,duplicate?copyCel(l.cels[current]):makeCanvas(project.width,project.height))}state.frame=current+1;refreshAll();changed();toast(duplicate?'Frame duplicated':'Empty frame added')}
function deleteFrame(){if(project.frames.length===1)return toast('Keep at least one frame');checkpoint();project.frames.splice(state.frame,1);for(const l of project.layers)l.cels.splice(state.frame,1);state.frame=clamp(state.frame,0,project.frames.length-1);refreshAll();changed()}
function addLayer(){if(project.layers.length>=64)return toast('Maximum 64 layers');if(!fitsMemoryBudget(project.width,project.height,project.frames.length,project.layers.length+1))return toast('Document memory limit reached');checkpoint();project.layers.splice(state.layer+1,0,layer('Layer '+(project.layers.length+1),project.width,project.height,project.frames.length));state.layer++;refreshAll();changed();toast('Layer added')}
function deleteLayer(){if(project.layers.length===1)return toast('Keep at least one layer');checkpoint();project.layers.splice(state.layer,1);state.layer=clamp(state.layer,0,project.layers.length-1);refreshAll();changed()}
function moveLayer(delta){const next=state.layer+delta;if(next<0||next>=project.layers.length)return;checkpoint();[project.layers[state.layer],project.layers[next]]=[project.layers[next],project.layers[state.layer]];state.layer=next;refreshAll();changed()}
function resizeCanvas(w,h){if(w===project.width&&h===project.height)return;if(!fitsMemoryBudget(w,h,project.frames.length,project.layers.length))return toast('New canvas would exceed memory limit');checkpoint();for(const l of project.layers)l.cels=l.cels.map(c=>{const out=makeCanvas(w,h);ctx(out).drawImage(c,0,0);return out});project.width=w;project.height=h;state.selection=null;refreshAll();fit();changed();toast(`Canvas resized to ${w} × ${h}`)}
function newDocument(w,h,name,white){project=blankProject(w,h,name,white);history=[];future=[];state.frame=0;state.layer=0;state.selection=null;state.panX=state.panY=0;stopPlayback();refreshAll();fit();changed();toast('New sprite created')}
function togglePlay(){state.playing=!state.playing;animationLast=performance.now();animationTime=0;updateInspector()}
function animationLoop(timestamp){if(state.playing&&project){animationTime+=Math.min(250,timestamp-animationLast||0);while(animationTime>=project.frames[state.frame].duration){animationTime-=project.frames[state.frame].duration;state.frame=(state.frame+1)%project.frames.length;renderCanvas();updateTimeline();updateMetadata()}}animationLast=timestamp;requestAnimationFrame(animationLoop)}
// ----- Import, export, native GIF89a encoder -----
function download(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000)}
function downloadCanvas(c,name){c.toBlob(blob=>{if(blob)download(blob,name);else toast('Image encoding failed')},'image/png')}
function saveProject(){download(new Blob([JSON.stringify(serialize())],{type:'application/json'}),safeName(project.name)+'.npx');autosave();toast('Editable project downloaded')}
function exportFrame(){downloadCanvas(composeFrame(state.frame),`${safeName(project.name)}-frame-${String(state.frame+1).padStart(2,'0')}.png`);toast('PNG exported')}
function sheetLayout(){const columns=Math.ceil(Math.sqrt(project.frames.length)),rows=Math.ceil(project.frames.length/columns);return {columns,rows,width:columns*project.width,height:rows*project.height}}
function createSpriteSheet(){const d=sheetLayout();if(d.width>16384||d.height>16384)throw Error('Sprite sheet exceeds browser canvas limit');const sheet=makeCanvas(d.width,d.height),c=ctx(sheet);project.frames.forEach((f,i)=>c.drawImage(composeFrame(i),i%d.columns*project.width,Math.floor(i/d.columns)*project.height));return sheet}
function exportSheet(){try{downloadCanvas(createSpriteSheet(),safeName(project.name)+'-spritesheet.png');toast('Sprite sheet exported')}catch(e){toast(e.message)}}
function exportAtlas(){const s=sheetLayout(),name=safeName(project.name);const payload={meta:{app:'Nexus Pixel Studio',version:'0.1',image:name+'-spritesheet.png',format:'RGBA8888',size:{w:s.width,h:s.height},scale:'1'},frames:project.frames.map((f,i)=>({filename:`${name}-${String(i+1).padStart(3,'0')}`,frame:{x:(i%s.columns)*project.width,y:Math.floor(i/s.columns)*project.height,w:project.width,h:project.height},rotated:false,trimmed:false,sourceSize:{w:project.width,h:project.height},duration:f.duration}))};download(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),name+'-atlas.json');toast('Atlas metadata exported')}
function makeGIF(){
 // Exact palette if <=255 opaque colors; nearest-color fallback if artwork exceeds 255.
 const frames=project.frames.map((_,i)=>ctx(composeFrame(i)).getImageData(0,0,project.width,project.height).data);
 const colors=[[0,0,0]],colorIds=new Map(),histogram=new Map();for(const data of frames)for(let i=0;i<data.length;i+=4){if(data[i+3]<128)continue;const key=(data[i]<<16)|(data[i+1]<<8)|data[i+2];histogram.set(key,(histogram.get(key)||0)+1)}
 const frequent=[...histogram].sort((a,b)=>b[1]-a[1]).slice(0,255).map(x=>x[0]);for(const key of frequent){colorIds.set(key,colors.length);colors.push([(key>>16)&255,(key>>8)&255,key&255])}
 function nearest(key){if(colorIds.has(key))return colorIds.get(key);const r=(key>>16)&255,g=(key>>8)&255,b=key&255;let best=1,distance=Infinity;for(let p=1;p<colors.length;p++){const c=colors[p],d=(r-c[0])**2*2+(g-c[1])**2*3+(b-c[2])**2;if(d<distance){distance=d;best=p}}colorIds.set(key,best);return best}
 const out=[];const bytes=(...a)=>out.push(...a);const short=x=>bytes(x&255,(x>>8)&255);const str=s=>{for(let i=0;i<s.length;i++)bytes(s.charCodeAt(i))};
 str('GIF89a');short(project.width);short(project.height);bytes(0xF7,0,0);
 for(let i=0;i<256;i++){const c=colors[i]||[0,0,0];bytes(c[0],c[1],c[2])}
 bytes(0x21,0xFF,11);str('NETSCAPE2.0');bytes(3,1,0,0,0);
 for(let f=0;f<frames.length;f++){
  const duration=clamp(Math.round(project.frames[f].duration/10),2,65535);
  bytes(0x21,0xF9,4,0x09);short(duration);bytes(0,0);
  bytes(0x2C);short(0);short(0);short(project.width);short(project.height);bytes(0);
  bytes(8);const codes=[];const data=frames[f];for(let i=0;i<data.length;i+=4){if((i/4)%200===0)codes.push(256);codes.push(data[i+3]<128?0:nearest((data[i]<<16)|(data[i+1]<<8)|data[i+2]))}codes.push(257);
  // LZW with dictionary-clear every 200 pixels. Deliberately use 9-bit raw indices;
  // decoder resets before its code table can exceed 9 bits.
  const packed=[];let bits=0,held=0;for(const code of codes){held|=code<<bits;bits+=9;while(bits>=8){packed.push(held&255);held>>=8;bits-=8}}if(bits)packed.push(held&255);
  for(let i=0;i<packed.length;i+=255){const block=packed.slice(i,i+255);bytes(block.length,...block)}bytes(0);
 }
 bytes(0x3B);return new Uint8Array(out);
}
function exportGIF(){try{download(new Blob([makeGIF()],{type:'image/gif'}),safeName(project.name)+'.gif');toast('Animated GIF exported')}catch(e){console.error(e);toast('GIF export failed: '+e.message)}}
async function openFile(file){if(!file)return;try{if(file.name.toLowerCase().endsWith('.npx')||file.type==='application/json'||file.name.toLowerCase().endsWith('.json')){await loadSerialized(JSON.parse(await file.text()));return}
 if(!file.type.startsWith('image/'))throw Error('Unsupported file type');const url=URL.createObjectURL(file);const image=new Image();image.src=url;await image.decode();URL.revokeObjectURL(url);if(image.width>512||image.height>512)throw Error('Images must be 512 × 512 px or smaller');newDocument(image.width,image.height,file.name.replace(/\.[^.]+$/,''),false);ctx(selectedCel()).drawImage(image,0,0);refreshAll();changed();toast('Image imported as editable pixels')
 }catch(err){console.error(err);toast('Open failed: '+err.message)}}
// ----- User interface wiring -----
function action(name){document.querySelectorAll('.menu-group.open').forEach(x=>x.classList.remove('open'));switch(name){
 case 'new':$('newDialog').showModal();break;
 case 'open':$('fileInput').click();break;
 case 'save':saveProject();break;
 case 'png':exportFrame();break;
 case 'sheet':exportSheet();break;
 case 'gif':exportGIF();break;
 case 'atlas':exportAtlas();break;
 case 'undo':undo();break;
 case 'redo':redo();break;
 case 'copy':copySelection();break;
 case 'cut':copySelection(true);break;
 case 'paste':pasteSelection();break;
 case 'delete-selection':deleteSelection();break;
 case 'deselect':state.selection=null;updateSelectionBox();break;
 case 'resize':$('resizeForm').elements.width.value=project.width;$('resizeForm').elements.height.value=project.height;$('resizeDialog').showModal();break;
 case 'flip-h':applyFlip(true);break;
 case 'flip-v':applyFlip(false);break;
 case 'clear-cel':deleteSelection();break;
 case 'toggle-grid':state.grid=!state.grid;updateArtboard();updateInspector();break;
 case 'toggle-onion':state.onion=!state.onion;renderCanvas();updateInspector();break;
 case 'add-frame':addFrame();break;
 case 'duplicate-frame':addFrame(true);break;
 case 'delete-frame':deleteFrame();break;
 case 'play':togglePlay();break;
 default:console.warn('Unsupported action',name)
}}
function bindUI(){
 document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>action(b.dataset.action)));
 document.querySelectorAll('[data-tool]').forEach(b=>b.addEventListener('click',()=>setTool(b.dataset.tool)));
 document.querySelectorAll('.menu-trigger').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();const g=b.parentElement;document.querySelectorAll('.menu-group.open').forEach(x=>{if(x!==g)x.classList.remove('open')});g.classList.toggle('open')}));
 document.addEventListener('pointerdown',e=>{if(!e.target.closest('.menu-group'))document.querySelectorAll('.menu-group.open').forEach(x=>x.classList.remove('open'))});
 const viewport=$('viewport');viewport.addEventListener('pointerdown',handlePointerDown);viewport.addEventListener('pointermove',handlePointerMove);viewport.addEventListener('pointerup',handlePointerUp);viewport.addEventListener('pointercancel',handlePointerUp);viewport.addEventListener('contextmenu',e=>e.preventDefault());
 viewport.addEventListener('wheel',e=>{e.preventDefault();setZoom(state.zoom+(e.deltaY<0?1:-1))},{passive:false});
 $('zoomIn').onclick=()=>setZoom(state.zoom+1);$('zoomOut').onclick=()=>setZoom(state.zoom-1);$('fitBtn').onclick=fit;
 $('brushSize').oninput=e=>{state.brush=Number(e.target.value);$('brushSizeLabel').textContent=state.brush+' px'};
 $('filledToggle').onclick=()=>{state.filled=!state.filled;updateInspector()};$('symXToggle').onclick=()=>{state.symX=!state.symX;updateInspector()};$('symYToggle').onclick=()=>{state.symY=!state.symY;updateInspector()};
 $('gridToggle').onclick=()=>action('toggle-grid');$('onionToggle').onclick=()=>action('toggle-onion');
 $('colorPicker').oninput=e=>setForeground(e.target.value);$('colorHex').addEventListener('change',e=>{if(normalHex(e.target.value))setForeground(e.target.value);else updateInspector()});
 $('swapColors').onclick=swapColors;$('fgSwatch').onclick=()=>$('colorPicker').click();$('bgSwatch').onclick=swapColors;
 $('paletteSelect').onchange=e=>{const key=e.target.value;checkpoint();if(key==='CUSTOM'){project.paletteKey='CUSTOM'}else{project.paletteKey=key;project.palette=PALETTES[key].map(x=>'#'+x)}updateInspector();changed()};
 $('addColorBtn').onclick=()=>{if(project.palette.length>=256)return toast('Palette limit: 256 swatches');checkpoint();project.paletteKey='CUSTOM';project.palette.push(state.fg);updateInspector();changed();toast('Color added to palette')};
 $('docName').addEventListener('focus',e=>e.target.dataset.old=e.target.value);$('docName').addEventListener('change',e=>{const name=e.target.value.trim().slice(0,60)||'Untitled Sprite';if(name!==project.name){checkpoint();project.name=name;refreshAll();changed()}});
 $('layerName').addEventListener('change',e=>{const name=e.target.value.trim().slice(0,40);if(name&&name!==selectedLayer().name){checkpoint();selectedLayer().name=name;refreshAll();changed()}});
 $('layerOpacity').addEventListener('change',e=>{const val=Number(e.target.value)/100;if(selectedLayer().opacity!==val){checkpoint();selectedLayer().opacity=val;refreshAll();changed()}});
 $('layerOpacity').addEventListener('input',e=>$('opacityReadout').textContent=e.target.value+'%');
 $('toggleLayerVisibility').onclick=()=>{checkpoint();selectedLayer().visible=!selectedLayer().visible;refreshAll();changed()};$('toggleLayerLock').onclick=()=>{checkpoint();selectedLayer().locked=!selectedLayer().locked;refreshAll();changed()};
 $('layerUp').onclick=()=>moveLayer(1);$('layerDown').onclick=()=>moveLayer(-1);$('deleteLayerBtn').onclick=deleteLayer;$('addLayerBtn').onclick=addLayer;
 $('addFrameBtn').onclick=()=>addFrame();$('duplicateFrameBtn').onclick=()=>addFrame(true);$('deleteFrameBtn').onclick=deleteFrame;
 $('firstFrameBtn').onclick=()=>{state.frame=0;refreshAll()};$('lastFrameBtn').onclick=()=>{state.frame=project.frames.length-1;refreshAll()};
 $('prevFrameBtn').onclick=()=>{state.frame=(state.frame-1+project.frames.length)%project.frames.length;refreshAll()};$('nextFrameBtn').onclick=()=>{state.frame=(state.frame+1)%project.frames.length;refreshAll()};$('playBtn').onclick=togglePlay;$('previewToggle').onclick=togglePlay;
 $('fpsInput').addEventListener('change',e=>{const fps=clamp(Math.round(Number(e.target.value)||8),1,30);checkpoint();for(const f of project.frames)f.duration=Math.round(1000/fps);updateInspector();changed()});
 $('fileInput').onchange=e=>{openFile(e.target.files[0]);e.target.value=''};
 $('newForm').onsubmit=e=>{e.preventDefault();const fd=new FormData(e.target);const w=Number(fd.get('width')),h=Number(fd.get('height'));if(!Number.isInteger(w)||!Number.isInteger(h)||w<1||h<1||w>512||h>512){toast('Use dimensions from 1 to 512 pixels');return}newDocument(w,h,String(fd.get('name')||'Untitled Sprite'),fd.get('background')==='white');$('newDialog').close()};
 $('resizeForm').onsubmit=e=>{e.preventDefault();const fd=new FormData(e.target),w=Number(fd.get('width')),h=Number(fd.get('height'));if(!Number.isInteger(w)||!Number.isInteger(h)||w<1||h<1||w>512||h>512){toast('Use dimensions from 1 to 512 pixels');return}resizeCanvas(w,h);$('resizeDialog').close()};
 $('newCancel').onclick=()=>$('newDialog').close();$('resizeCancel').onclick=()=>$('resizeDialog').close();$('helpBtn').onclick=()=>$('helpDialog').showModal();$('helpClose').onclick=()=>$('helpDialog').close();
 document.addEventListener('keydown',e=>{
  const input=e.target.closest('input,select,textarea,dialog');if(input&&!(e.ctrlKey&&['s','o','n'].includes(e.key.toLowerCase())))return;
  const k=e.key.toLowerCase(),ctrl=e.ctrlKey||e.metaKey;
  if(ctrl){const cmds={z:e.shiftKey?'redo':'undo',y:'redo',s:'save',o:'open',n:'new',c:'copy',x:'cut',v:'paste',d:'deselect'};if(cmds[k]){e.preventDefault();action(cmds[k]);return}}
  const tools={p:'pencil',e:'eraser',g:'fill',i:'eyedropper',d:'dither',l:'line',r:'rect',o:'ellipse',m:'select',v:'move',h:'hand'};
  if(tools[k]){setTool(tools[k]);return}
  if(k===' '){state.space=true;e.preventDefault();return}
  if(k==='x'){swapColors();return}
  if(k==='enter'){togglePlay();e.preventDefault();return}
  if(k==='['){state.brush=clamp(state.brush-1,1,16);updateInspector();return}
  if(k===']'){state.brush=clamp(state.brush+1,1,16);updateInspector();return}
  if(k==='delete'||k==='backspace'){e.preventDefault();deleteSelection();return}
  if(k==='arrowleft'||k===','){state.frame=(state.frame-1+project.frames.length)%project.frames.length;refreshAll();return}
  if(k==='arrowright'||k==='.'){state.frame=(state.frame+1)%project.frames.length;refreshAll();return}
 });
 document.addEventListener('keyup',e=>{if(e.code==='Space')state.space=false});
 window.addEventListener('blur',()=>{state.space=false;state.drag=null});
 window.addEventListener('beforeunload',()=>{if(state.dirty)autosave()});
}
async function init(){bindUI();try{const stored=localStorage.getItem('nexus-pixel-studio-autosave-v1');if(stored){await loadSerialized(JSON.parse(stored));$('saveStatus').textContent='Recovered locally'}else{project=seedProject();refreshAll();fit();autosave()}}catch(e){console.warn('Autosave restore unsuccessful; using starter sprite',e);project=seedProject();refreshAll();fit();toast('Starter sprite loaded; recovery failed')}requestAnimationFrame(animationLoop)}
// Diagnostic, read-only data surface for smoke tests and downstream integrations.
window.NexusStudio={getInfo:()=>({name:project.name,width:project.width,height:project.height,frames:project.frames.length,layers:project.layers.map(l=>({name:l.name,visible:l.visible,locked:l.locked,opacity:l.opacity})),selectedFrame:state.frame,selectedLayer:state.layer,tool:state.tool,zoom:state.zoom,playing:state.playing}),getPixel:(x,y,frame=state.frame,layerIndex=null)=>Array.from(ctx(layerIndex===null?composeFrame(frame):project.layers[layerIndex].cels[frame]).getImageData(x,y,1,1).data),toProject:()=>serialize(),toGIF:()=>makeGIF(),toSheet:()=>createSpriteSheet().toDataURL('image/png')};
init();
