from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path('/mnt/data/nexus-pixel-studio')
html=(p/'index.html').read_text().replace('<link rel="stylesheet" href="style.css" />','').replace('<script src="app.js"></script>','')
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(accept_downloads=True)
 page.set_content(html);page.add_style_tag(content=(p/'style.css').read_text());page.evaluate("""() => { let d={}; Object.defineProperty(window,'localStorage',{configurable:true,value:{setItem:(k,v)=>d[k]=v,getItem:k=>d[k]??null}}) }""");page.add_script_tag(content=(p/'app.js').read_text());page.wait_for_function('NexusStudio.getInfo().width>0')
 for label in ('png','gif','sheet','save'):
  try:
   with page.expect_download(timeout=3000) as dl:page.locator('.export-tiles [data-action="'+label+'"]').click()
   file=dl.value;print('PASS download',label,file.suggested_filename);file.save_as(str(p/('downloaded-'+file.suggested_filename)))
  except Exception as e:print('BLOCKED download',label,str(e)[:200])
 browser.close()
