# Nexus Pixel Studio — Aseprite-competitive production roadmap

## Product outcome

A dedicated, offline-capable pixel-art and animation editor with Aseprite-class precision, professional timeline tools, game-engine export, and direct integration with existing Nexus Pixel generators (Fantasy Tilesets, Fantasy Characters, Effects, Inventory). **This is a target, not a claim that all parity features already exist.**

## Architecture

```mermaid
flowchart TD
  A{Document open?} -->|Yes| B[Validate sprite model]
  A -->|No| C[Create RGBA document]
  B --> D[Layer × frame cels]
  C --> D
  D --> E[Command-based editing]
  E --> F[Renderer + timeline]
  F --> G{Export target?}
  G -->|Native| H[Lossless project file]
  G -->|Sprite| I[PNG / GIF / Atlas]
  G -->|Engine| J[Unity / Godot metadata]
```

### Stage 1 — Editable studio baseline (implemented and browser-tested)

- Canvas: pixel-scale strokes, nearest-neighbor zoom/pan, grid and symmetrical painting.
- Drawing: pencil, eraser, dither, fill, sampler, line, rectangle and ellipse.
- Selection: marquee, cut/copy/paste, move, flips and clear.
- Layers: visibility, lock, opacity, ordering, rename, independently editable per-frame cels.
- Animation: duplicate/insert/delete frames, duration, preview, onion skin.
- Colors: RGB editing, curated/custom palette swatches, hex input and color picker.
- Files: PNG import, native JSON+PNG `.npx`, PNG / GIF / sprite-sheet PNG / JSON atlas exports.
- Reliability: local autosave and recovery, 24 undo checkpoints or 80-MB history; 96-MB cel storage cap.

### Stage 2 — Professional editor parity

**Target:** no ambiguity or missing operations in routine hand-drawn sprite work.

- Pixel-perfect brush interpolation, continuous strokes, custom shapes and reusable brush stamps.
- Rectangle/lasso/magic-wand masks, selection modifiers, selection transforms, rotate, scale and skew.
- Layer groups, blend modes, linked cels, reference layers, duplicate cels, timeline drag-reorder.
- Full palette editor, indexed/grayscale modes, transparency-index mapping, palette animation.
- Frame tags, playback ranges, forward/reverse/ping-pong, variable duration, animation events.
- Tileable canvas wrap mode, spritesheet import, PNG sequence import and export.

**Acceptance:** deterministic golden-pixel tests for each tool, modifier, selection and undo/redo; zero untracked changes on save/reload; keyboard/pointer parity; no frame-cel aliasing unless linked deliberately.

### Stage 3 — Nexus Pixel specialization

- Tilemap builder with reusable tile cells, autotiling rules and multi-layer maps.
- Character animation sheets: 8×8 through 64×64, nine frames per action and reusable action state sets (idle/walk/run/attack/dodge).
- Effects timeline and particles to turn the Nexus Pixel Effects library into editable frame animations.
- Import work from Fantasy Tilesets, Fantasy Characters, Effects and Inventory editions as native `.npx` layers and frames.
- Palette swaps and non-destructive procedural generation on editable cels.

**Acceptance:** every generated result can be opened, modified by hand, animated and exported without visual discrepancy from the source pixels.

### Stage 4 — Game production pipeline

- `.aseprite`/`.ase` interoperable import/export where permitted and technically verified.
- Unity 2D, Godot 4, generic JSON texture atlas, named slices, collision tags, origins/pivots.
- CLI batch export and reproducible manifest; asset validation and naming conventions.
- Native desktop shells for Windows, macOS and Linux, with file associations and crash recovery.

**Acceptance:** validated round-trip tests; exported atlases match independent consumer renderers; desktop save/open survives restarts and unexpected shutdowns.

### Stage 5 — Performance / commercial release

- Switch PNG data-URI project storage to compact binary chunk format.
- IndexedDB/OPFS autosave and history diffs to avoid localStorage quotas.
- Tiled renderer / worker-based raster operations; large projects, streaming thumbnails and constant-time cel selection.
- Animation/spritesheet viewport regression testing across 8×8 to 512×512 projects.
- Accessible UI polish, tutorial projects, shortcut customization, UX telemetry opt-in only, packaged offline docs.

**Acceptance:** test against selected Aseprite workflows on identical source sprites, compare pixel outputs, UI action counts, memory and export compatibility. Publish a transparent parity matrix instead of unverified "full Aseprite replacement" claims.

## Release sequence

1. **0.1 — Functional studio:** runnable browser application with editing, timeline and verified exports (this build).
2. **0.2 — Editing parity:** advanced selections/brushes, linked cels, tags, palette index.
3. **0.3 — Nexus Pixel workflows:** first-class tileset, characters and effects editors.
4. **0.4 — Interoperability:** engine pipelines and Aseprite source import/export.
5. **1.0 — Commercial release:** full data-recovery, QA, platform packaging and accessibility gates.

No GitHub repository or publishing deployment has been modified for this build.
