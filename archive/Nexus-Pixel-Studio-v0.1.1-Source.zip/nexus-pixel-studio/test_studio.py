import json,time,os
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path('/mnt/data/nexus-pixel-studio')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1500,'height':950},accept_downloads=True)
 errs=[]
 page.on('pageerror',lambda e: errs.append(str(e)))
 html=(root/'index.html').read_text().replace('<link rel="stylesheet" href="style.css" />','').replace('<script src="app.js"></script>','')
 page.set_content(html,wait_until='load')
 page.add_style_tag(content=(root/'style.css').read_text())
 page.evaluate("""() => {let data={};Object.defineProperty(window,'localStorage',{configurable:true,value:{setItem:(k,v)=>data[k]=v,getItem:k=>data[k]??null,removeItem:k=>delete data[k]}})}""")
 page.add_script_tag(content=(root/'app.js').read_text())
 page.wait_for_timeout(1400)
 print('TITLE',page.title()); print('ERRORS',errs)
 try: print('INFO',page.evaluate('NexusStudio.getInfo()'))
 except Exception as e: print('INFO ERROR',e)
 page.screenshot(path=str(root/'screenshot_initial.png'),full_page=True)
 print('SCREENSHOT',os.path.getsize(root/'screenshot_initial.png'))
 browser.close()
