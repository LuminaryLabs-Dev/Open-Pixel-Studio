# Nexus Pixel Studio (v0.1.1)

A **working, local-first pixel art editor** for Nexus Pixel. It is a browser-based pixel studio, not a static mockup. No installation, server, account, backend, CDN or telemetry is required.

## Launch

Open `index.html` in Chrome, Edge, or Firefox. For itch.io HTML5 upload, zip `index.html`, `app.js`, and `style.css` at the archive root and select HTML5 as the project type.

## Included in this build

- Separate RGBA cels for each **layer × animation frame**; layer visibility, lock, opacity, naming and ordering.
- Editable frames, duplicate, delete, frame durations and looping animation playback.
- Pencil, eraser, flood fill, eyedropper, dithering, line, rectangle, ellipse, marquee select, move, hand/pan.
- Square brush sizing, symmetrical painting, pixel grid, nearest-neighbor zoom, onion skin, live preview.
- Copy/cut/paste selected pixels, clear selection, flip horizontal/vertical, canvas resize, undo/redo.
- DawnBringer 32, PICO-8, Fantasy 24 and customizable palette swatches (double-click a swatch to edit).
- File open: `.npx` native editable projects, PNG / WebP import into a new single-layer canvas.
- File export: current PNG frame, transparent PNG sprite sheet, frame-atlas JSON metadata, animated GIF, editable `.npx`.
- Browser-local autosave and startup recovery, keyboard shortcuts, working starter animation.

**Known limitations vs Aseprite:** no `.ase`/`.aseprite` importer, indexed or grayscale document engine, linked cels, masks, bezier/rotation transforms, tilemap layers, tile palettes, palettes saved as separate files, custom brushes, plug-in scripting, or desktop application shell yet. GIF uses a lossless-indexed palette for up to 255 opaque colors, with nearest-color fallback above that; pixels with alpha below 128 are transparent, and partial alpha is not preserved in GIF. Undo history is capped at 24 snapshots or 80 MB. Active cel storage is capped at approximately 96 MB. Autosave size is constrained by the browser's localStorage quota (monitor the save status).

## Keyboard shortcuts

P pencil · E eraser · G fill · I eyedropper · D dither · L line · R rectangle · O ellipse · M select · V move · H hand · X swap foreground/background · [ and ] brush size · Space+drag pan · mouse wheel zoom · Ctrl+Z/Y undo/redo · Ctrl+S save `.npx` · Ctrl+O open · Ctrl+N new · Ctrl+C/X/V copy/cut/paste · Ctrl+D deselect · Delete clear selection/cel · Left/Right frame stepping · Enter play.

## Native file format

`.npx` is human- and machine-readable JSON with metadata, palette, ordered layers, frame durations and each cel encoded as a PNG data URI. The `.npx` format is specific to Nexus Pixel Studio; it is **not** an Aseprite file. Sprite-sheet atlas JSON describes all frames with rectangle coordinates, duration, frame size, and filenames.

## Architecture and next parity milestones

The code is intentionally dependency-free. The RGBA cel model can be extracted into a WASM/NexusEngine document core. Recommended next milestones: (1) tiled-mode, tilemaps and tile palette; (2) advanced selections, masks, brushes and transformations; (3) indexed-mode palette semantics, groups/linked cels and frame tags; (4) `.aseprite` import/export interop and GIF/APNG/sequence import; (5) resilient large-project storage in IndexedDB, binary project format and layered undo diffing; (6) native desktop packaging, plugin API and command palette. These are **not** implemented in v0.1.1.

## Scope / security

Everything runs client-side. Data is stored in the current browser's localStorage and only downloaded when you export. Keep `.npx` project backups. No files are pushed to GitHub and no uploads are performed by the application.
