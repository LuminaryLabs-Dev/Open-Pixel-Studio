from pathlib import Path
from io import BytesIO
import json,time,os
from PIL import Image
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data/nexus-pixel-studio')

def load(page):
 html=(ROOT/'index.html').read_text().replace('<link rel="stylesheet" href="style.css" />','').replace('<script src="app.js"></script>','')
 page.set_content(html,wait_until='load')
 page.add_style_tag(content=(ROOT/'style.css').read_text())
 page.evaluate("""() => {let data={};Object.defineProperty(window,'localStorage',{configurable:true,value:{setItem:(k,v)=>data[k]=v,getItem:k=>data[k]??null,removeItem:k=>delete data[k]}})}""")
 page.add_script_tag(content=(ROOT/'app.js').read_text())
 page.wait_for_function('window.NexusStudio && NexusStudio.getInfo().width > 0')

def px(page,x,y):return page.evaluate('([x,y])=>NexusStudio.getPixel(x,y)',[x,y])

def paint(page,x,y,from_pos=None):
 board=page.locator('#artboard').bounding_box();zoom=page.evaluate('NexusStudio.getInfo().zoom');pxl=lambda x,y:(board['x']+(x+.5)*zoom,board['y']+(y+.5)*zoom)
 if from_pos:
  page.mouse.move(*pxl(*from_pos));page.mouse.down();page.mouse.move(*pxl(x,y),steps=7);page.mouse.up()
 else:page.mouse.click(*pxl(x,y))

with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1500,'height':950},accept_downloads=True)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 load(page)
 assert page.evaluate('NexusStudio.getInfo().layers.length')==3
 assert page.locator('.palette-swatch').count()==24
 assert page.locator('.palette-swatch').first.evaluate("el=>getComputedStyle(el).backgroundColor") != 'rgb(255, 255, 255)'
 print('PASS load/appearance')
 before=px(page,4,4);assert before[3]==0,before
 paint(page,4,4)
 after=px(page,4,4);assert after[:3]==[166,227,95] and after[3]==255,(before,after)
 page.locator('#undoBtn').click();assert px(page,4,4)[3]==0
 page.locator('#redoBtn').click();assert px(page,4,4)==after
 print('PASS drawing/undo/redo')
 page.locator('[data-tool=eraser]').click();paint(page,4,4);assert px(page,4,4)[3]==0
 print('PASS erase')
 page.locator('#addFrameBtn').click();assert page.evaluate('NexusStudio.getInfo().frames')==5
 assert px(page,4,4)[3]==0
 page.locator('#duplicateFrameBtn').click();assert page.evaluate('NexusStudio.getInfo().frames')==6
 page.locator('#deleteFrameBtn').click();assert page.evaluate('NexusStudio.getInfo().frames')==5
 page.locator('#addLayerBtn').click();assert page.evaluate('NexusStudio.getInfo().layers.length')==4
 page.locator('#layerName').fill('Special FX');page.locator('#layerName').press('Tab')
 assert page.evaluate('NexusStudio.getInfo().layers[2].name')=='Special FX'
 print('PASS frames/layers/rename')
 # Draw pixel on special FX layer in current frame, then select and move.
 page.locator('[data-tool=pencil]').click();paint(page,8,8)
 assert px(page,8,8)[:3]==[166,227,95]
 page.locator('[data-tool=select]').click();paint(page,9,9,from_pos=(7,7))
 page.locator('[data-tool=move]').click();paint(page,15,12,from_pos=(8,8))
 assert px(page,8,8)[3]==0, px(page,8,8)
 assert px(page,15,12)[:3]==[166,227,95],px(page,15,12)
 print('PASS marquee/move')
 page.locator('#gridToggle').click();assert page.locator('#pixelGrid').evaluate("el=>el.classList.contains('on')")
 page.locator('#onionToggle').click();assert page.locator('#onionToggle').evaluate("el=>el.classList.contains('selected')")
 print('PASS grid/onion')
 # Verify GIF structure and decoded playback in PIL.
 data=bytes(page.evaluate('Array.from(NexusStudio.toGIF())'))
 gif=Image.open(BytesIO(data));assert gif.format=='GIF';assert gif.size==(48,48);assert gif.n_frames==5
 for i in range(gif.n_frames):gif.seek(i);gif.convert('RGBA').getpixel((24,27))
 print('PASS GIF',len(data),'bytes',gif.n_frames,'frames')
 # Spritesheet image dimensions.
 dataurl=page.evaluate('NexusStudio.toSheet()');assert dataurl.startswith('data:image/png;base64,')
 import base64
 png=Image.open(BytesIO(base64.b64decode(dataurl.split(',',1)[1])))
 assert png.size==(144,96),png.size
 print('PASS spritesheet',png.size)
 # Project round-trip and atlas JSON.
 serialized=page.evaluate('NexusStudio.toProject()');assert len(serialized['layers'])==4;assert len(serialized['layers'][0]['cels'])==5
 page.locator('#fileInput').set_input_files({'name':'restored.npx','mimeType':'application/json','buffer':json.dumps(serialized).encode()})
 page.wait_for_timeout(800)
 assert page.evaluate('NexusStudio.getInfo().frames')==5
 print('PASS npx round trip')
 # New canvas, fill, flip, resize.
 page.locator('[data-menu=file]').click();page.locator('[data-action="new"]').click()
 page.locator('#newForm input[name=width]').fill('16');page.locator('#newForm input[name=height]').fill('20')
 page.locator('#newForm input[name=name]').fill('QA Test')
 page.locator('#newForm button[type=submit]').click()
 assert page.evaluate('NexusStudio.getInfo().width')==16
 page.locator('[data-tool=fill]').click();paint(page,0,0)
 assert px(page,15,19)[:3]==[166,227,95]
 page.locator('#undoBtn').click();assert px(page,15,19)[3]==0
 print('PASS new/flood-fill')
 page.locator('#layerUp').click(force=True) # No-op on single layer.
 page.locator('[data-menu=sprite]').click()
 page.locator('[data-action=resize]').click()
 page.locator('#resizeForm input[name=width]').fill('20')
 page.locator('#resizeForm button[type=submit]').click()
 assert page.evaluate('NexusStudio.getInfo().width')==20
 print('PASS resize')
 page.wait_for_timeout(1000)
 assert page.locator('#saveStatus').inner_text()=='Saved locally'
 assert not errors, errors
 print('PASS autosave and no page errors')
 page.screenshot(path=str(ROOT/'screenshot_verified.png'),full_page=True)
 (ROOT/'verified-animation.gif').write_bytes(data)
 (ROOT/'verified-spritesheet.png').write_bytes(base64.b64decode(dataurl.split(',',1)[1]))
 print('ALL TESTS PASSED')
 browser.close()
