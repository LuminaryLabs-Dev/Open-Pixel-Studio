from pathlib import Path
from io import BytesIO
from zipfile import ZipFile
import json
from PIL import Image
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data/nexus-pixel-studio')
DIST=Path('/mnt/data')
assert not any(x in (ROOT/'index.html').read_text()+(ROOT/'style.css').read_text() for x in ['https://fonts.googleapis.com','https://cdn.','http://cdn.'])
for name in ['Slime-Study.gif','Slime-Study-frame-01.png','Slime-Study-spritesheet.png']:
 im=Image.open(ROOT/'examples'/name);im.verify()
gif=Image.open(ROOT/'examples'/'Slime-Study.gif');assert gif.n_frames==4
with ZipFile(DIST/'Nexus-Pixel-Studio-v0.1.0-Itch-HTML5.zip') as z:
 assert set(z.namelist())=={'index.html','app.js','style.css','README.md'}
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1280,'height':800},accept_downloads=True)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 # Test exact merged standalone HTML (no separate source injection).
 page.set_content((DIST/'Nexus-Pixel-Studio-v0.1.0-Standalone.html').read_text())
 page.wait_for_function('window.NexusStudio && NexusStudio.getInfo().frames===4')
 assert page.locator('.cel').count()==12
 page.locator('[data-menu=file]').click()
 with page.expect_download() as download:
  page.locator('[data-action=atlas]').click()
 d=download.value;assert d.suggested_filename=='Slime-Study-atlas.json'
 dest=ROOT/'examples'/d.suggested_filename;d.save_as(str(dest))
 atlas=json.loads(dest.read_text());assert len(atlas['frames'])==4
 assert atlas['meta']['size']=={'w':96,'h':96}
 # Test shift-constrained pencil stroke, grid, 8x8 resize.
 page.locator('#newDialog').evaluate('el=>el.showModal()')
 page.locator('#newForm input[name=width]').fill('8')
 page.locator('#newForm input[name=height]').fill('8')
 page.locator('#newForm button[type=submit]').click()
 page.locator('#fitBtn').click()
 b=page.locator('#artboard').bounding_box();zoom=page.evaluate('NexusStudio.getInfo().zoom')
 xy=lambda x,y:(b['x']+(x+.5)*zoom,b['y']+(y+.5)*zoom)
 page.mouse.move(*xy(1,1));page.keyboard.down('Shift');page.mouse.down();page.mouse.move(*xy(6,6),steps=5);page.mouse.up();page.keyboard.up('Shift')
 assert page.evaluate('NexusStudio.getPixel(6,6)')[3]==255
 assert page.evaluate('NexusStudio.getPixel(1,6)')[3]==0
 assert not errors,errors
 print('PASS standalone exact HTML, atlas file download, GIF, PNG, shift drawing, 8x8, no JS errors')
 browser.close()
